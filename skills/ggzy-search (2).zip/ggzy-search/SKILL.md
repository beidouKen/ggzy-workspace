---
name: ggzy-search
description: 全国公共资源交易平台(ggzy)公告搜索与报告生成工具。当用户提到招标、投标、中标、开标、招标公告、中标公告、中标结果、招投标、招标信息、采购公告、政府采购、公共资源交易、交易公告、工程招标、货物招标、服务招标、竞争性谈判、竞争性磋商、询价公告、单一来源、资格预审、建设工程、土地使用权、矿业权、国有产权，或需要在全国公共资源交易平台上搜索、查询、抓取任何交易公告信息时使用此技能。支持自定义关键词搜索，自动翻页抓取全部结果并生成 HTML 报告。默认筛选广东省近十天的交易公告。
metadata: { "openclaw": { "emoji": "🔍" } }
---

# ggzy-search Skill

全国公共资源交易平台公告搜索与报告生成技能。

## 用途

搜索全国公共资源交易平台（https://www.ggzy.gov.cn/deal/dealList.html）上的交易公告，支持自定义关键词，自动翻页抓取全部结果，并生成 HTML 报告。

## 默认筛选条件

- **发布时间**：近十天
- **省份**：广东
- **信息类型**：交易公告

## 可变参数

- **关键词**：用户指定（如：医疗、足球、教育、建筑等）
- **省份**：可选覆盖，默认"广东"
- **翻页数**：可选，默认全部页

## ⚠️ 关键约束

1. **此网站不支持 URL 查询参数**——所有筛选条件必须通过页面 DOM 交互设置。禁止在 URL 上拼接 `keyword`、`province`、`timeRange` 等参数，拼了也不会生效。
2. 全局规则禁止 `browser act kind:fill` 和 `browser act kind:type`。**必须用 `browser evaluate` 执行 JavaScript 来注入文本和操作下拉框**。
3. 每次导航或 AJAX 请求后，aria ref 编号会失效。**每次交互前必须重新 `browser snapshot`** 获取最新 ref。
4. 筛选链接（近十天、交易公告等）是 `<a href="javascript:;">`，点击后会触发 AJAX 异步加载，**点击后必须 sleep 2-3 秒** 等待数据刷新。

## 操作流程

### Step 1：打开网站（不带任何参数）

```
browser navigate url:"https://www.ggzy.gov.cn/deal/dealList.html"
```

等待 3 秒让页面完全加载：

```
browser act kind:wait duration:3000
```

### Step 2：用 evaluate 一次性设置全部筛选条件 + 关键词 + 触发搜索

用一个 `browser evaluate` 调用完成所有设置并触发搜索。将 `<关键词>` 替换为用户指定的关键词，将 `<省份>` 替换为目标省份（默认"广东"）：

```javascript
browser evaluate expression:"(function() {
  // 1) 点击「近十天」
  var links = document.querySelectorAll('.search_tiaojian a');
  for (var i = 0; i < links.length; i++) {
    if (links[i].textContent.trim() === '近十天') {
      links[i].click();
      break;
    }
  }

  // 2) 选择省份
  var selects = document.querySelectorAll('select');
  for (var j = 0; j < selects.length; j++) {
    var opts = selects[j].options;
    for (var k = 0; k < opts.length; k++) {
      if (opts[k].text === '<省份>') {
        selects[j].value = opts[k].value;
        selects[j].dispatchEvent(new Event('change', {bubbles: true}));
        break;
      }
    }
  }

  // 3) 点击「交易公告」
  for (var m = 0; m < links.length; m++) {
    if (links[m].textContent.trim() === '交易公告') {
      links[m].click();
      break;
    }
  }

  // 4) 输入关键词
  var input = document.querySelector('input[placeholder*=\"关键字\"]');
  if (!input) input = document.querySelector('.search_key input');
  if (input) {
    var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeInputValueSetter.call(input, '<关键词>');
    input.dispatchEvent(new Event('input', {bubbles: true}));
    input.dispatchEvent(new Event('change', {bubbles: true}));
  }

  // 5) 点击搜索按钮
  var btns = document.querySelectorAll('button, input[type=button], a');
  for (var n = 0; n < btns.length; n++) {
    if (btns[n].textContent.trim() === '搜索') {
      btns[n].click();
      return 'ok: filters set, search triggered';
    }
  }
  // 备选：直接调用 onclick
  var searchBtn = document.querySelector('.search_btn') || document.querySelector('[onclick*=search]');
  if (searchBtn) { searchBtn.click(); return 'ok: fallback search clicked'; }
  return 'error: search button not found';
})()"
```

执行后等待 3 秒让搜索结果加载：

```
browser act kind:wait duration:3000
```

### Step 3：验证筛选条件是否生效

```
browser screenshot
```

检查截图确认：
- 「近十天」处于选中/高亮状态
- 省份下拉框显示正确的省份
- 「交易公告」处于选中/高亮状态
- 搜索结果已刷新（标题和省份与预期一致）

**如果筛选条件未生效**，重新执行 Step 2。

### Step 4：抓取第 1 页数据

```
browser snapshot refs:"aria"
```

从 snapshot 中提取：
- 搜索记录总数（形如"搜索记录数:XXX"）
- 每条公告的：标题、日期、省份、来源平台、业务类型、信息类型、详情链接
- 分页信息（形如"页码X/Y"）
- 翻页按钮的 ref 编号

截图保存：

```
browser screenshot
```

### Step 5：翻页抓取

对每一页执行以下循环：

```javascript
browser evaluate expression:"(function() {
  var pageLinks = document.querySelectorAll('.pagination a, .page a, [class*=page] a');
  for (var i = 0; i < pageLinks.length; i++) {
    if (pageLinks[i].textContent.trim() === '<目标页码>') {
      pageLinks[i].click();
      return 'ok: clicked page <目标页码>';
    }
  }
  // 备选：点击「下一页」
  for (var j = 0; j < pageLinks.length; j++) {
    if (pageLinks[j].textContent.indexOf('下一页') >= 0 || pageLinks[j].title === '下一页') {
      pageLinks[j].click();
      return 'ok: clicked next page';
    }
  }
  return 'error: page link not found';
})()"
```

等待 3 秒 → `browser screenshot` → `browser snapshot` 抓取数据。

重复直到达到用户指定的页数或没有更多页。

### Step 6：生成 HTML 报告

将所有收集到的公告信息整理成 HTML 文档，包含：
- 搜索条件摘要（关键词、省份、时间范围、信息类型）
- 总记录数和总页数
- 表格形式展示每条公告：序号、标题（可点击链接）、日期、省份、业务类型、信息类型
- 每页截图的缩略图

## 输出

- 搜索结果的 HTML 报告文件路径
- 每页截图的媒体路径列表

## 故障排除

| 现象 | 原因 | 处理 |
|------|------|------|
| 搜索结果显示全国数据，未按省份过滤 | evaluate 中省份选择未生效 | 重新 snapshot 确认 select 元素，检查 option text 是否精确匹配 |
| 点击"近十天"后结果未变化 | AJAX 未完成就截图了 | 增加等待时间到 5 秒 |
| ref 点击超时 | 页面交互后旧 ref 失效 | 重新 snapshot 获取最新 ref |
| 搜索按钮找不到 | DOM 结构可能有变化 | 用 snapshot 检查按钮实际标签和 class |
| 翻页无反应 | 页码链接定位不准 | 先 snapshot 找到分页区域的准确 ref，用 click ref |

## 示例调用

用户请求："帮我搜索广东近十天关于足球医疗的招标公告"

执行步骤：
1. `browser navigate` 打开基础 URL（不带参数）
2. `browser evaluate` 一次性设置：近十天 + 广东 + 交易公告 + 关键词"足球医疗" + 点击搜索
3. 等待 3 秒 → `browser screenshot` 验证筛选条件
4. `browser snapshot` 抓取第 1 页数据 + 截图
5. `browser evaluate` 翻到第 2 页 → 等待 → snapshot + 截图
6. 汇总所有结果生成 HTML 报告
