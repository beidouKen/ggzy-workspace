---
name: ggzy-search
description: 全国公共资源交易平台(ggzy)公告搜索与报告生成工具。当用户提到招标、投标、中标、开标、招标公告、中标公告、中标结果、招投标、招标信息、采购公告、政府采购、公共资源交易、交易公告、工程招标、货物招标、服务招标、竞争性谈判、竞争性磋商、询价公告、单一来源、资格预审、建设工程、土地使用权、矿业权、国有产权，或需要在全国公共资源交易平台上搜索、查询、抓取任何交易公告信息时使用此技能。支持自定义关键词搜索，自动翻页抓取全部结果并生成 HTML 报告。默认筛选广东省近十天的交易公告。
metadata: { "openclaw": { "emoji": "🔍" } }
---

# ggzy-search Skill

搜索全国公共资源交易平台（https://www.ggzy.gov.cn/deal/dealList.html）上的交易公告，支持单个或多个关键词，自动翻页抓取并生成按关键词分组的 HTML 报告。

## 🚨 执行纪律（最高优先级，必须遵守）

1. **禁止中途暂停询问用户**。循环中不得停下来问用户"要不要继续""要不要换方案"。但**纠错重试不算暂停**——验证失败时必须立即重试，这是流程的一部分。
2. **禁止尝试 Skill 未定义的替代方案**。不允许尝试 URL 参数、API 调用、web_fetch 或任何本文档未列出的方法。只用本文档定义的 `browser evaluate` 方式。
3. **验证失败必须立即修复，禁止跳过**。Step 4 验证不通过时，必须立即重试 Step 3（最多 2 次）。绝对不能"先跳过、后面再处理"。如果筛选条件不对就继续，后面所有关键词的结果全部作废。
4. **Step 4 是硬性门槛**。验证通过后才能进入关键词循环。如果重试 2 次仍失败，必须停下来告知用户"筛选条件设置失败"，不能带着错误的筛选继续执行。这是唯一允许中断并告知用户的情况。
5. **必须输出进度日志**。每完成一个关键词，立即输出：`[N/总数] 关键词: XX条 ✓` 或 `[N/总数] 关键词: 0条（无结果）✓`
6. **空结果只记录不处理**。循环中遇到 0 条结果，记入 emptyKeywords 后立即进入下一个关键词。
7. **必须生成 HTML 报告**。Step 9 不可跳过。

## 参数与约束

**默认筛选**：近十天 / 广东 / 交易公告

**可变参数**：
- 关键词（必填，一个或多个）：自然语言"医疗和足球" → `["医疗","足球"]`；列举式"医疗、足球" → `["医疗","足球"]`
- 省份（可选，默认"广东"）
- 翻页数（可选，默认全部页）

**技术约束**：
- 网站不支持 URL 查询参数，所有筛选条件必须通过 `browser evaluate` 操作 DOM
- 禁止 `browser act kind:fill` 和 `browser act kind:type`，必须用 evaluate 注入文本
- 每次导航/AJAX 后 aria ref 失效，交互前必须重新 snapshot
- 筛选链接点击后触发 AJAX，必须 sleep 2-3 秒等待加载

---

## 操作流程

### Step 1：解析关键词列表

从用户输入提取关键词数组。"和""与""以及"、顿号、逗号为分隔符。区分多关键词（"医疗和足球"→2 个）和组合关键词（"医疗设备"→1 个）。

初始化：`results = {}`, `emptyKeywords = []`

### Step 2：打开网站

```
browser navigate url:"https://www.ggzy.gov.cn/deal/dealList.html"
browser act kind:wait duration:3000
```

### Step 3：首次完整设置（仅第 1 个关键词执行）

**重要：必须分两步执行，中间加等待。不能合并成一个 evaluate，否则筛选条件不生效。**

#### Step 3a：设置筛选条件（近十天 + 省份 + 交易公告）

```javascript
browser evaluate expression:"(function() {
  function isActive(el) {
    var cl = el.className || '';
    var pcl = el.parentElement ? el.parentElement.className : '';
    return cl.indexOf('active') >= 0 || cl.indexOf('selected') >= 0 || cl.indexOf('on') >= 0
        || pcl.indexOf('active') >= 0 || pcl.indexOf('selected') >= 0 || pcl.indexOf('on') >= 0;
  }

  var links = document.querySelectorAll('.search_tiaojian a');
  for (var i = 0; i < links.length; i++) {
    if (links[i].textContent.trim() === '近十天') {
      if (!isActive(links[i])) links[i].click();
      break;
    }
  }

  var selects = document.querySelectorAll('select');
  for (var j = 0; j < selects.length; j++) {
    var opts = selects[j].options;
    for (var k = 0; k < opts.length; k++) {
      if (opts[k].text === '<省份>') {
        selects[j].value = opts[k].value;
        selects[j].dispatchEvent(new Event('change', {bubbles: true}));
        break;
      }
    }
  }

  for (var m = 0; m < links.length; m++) {
    if (links[m].textContent.trim() === '交易公告') {
      if (!isActive(links[m])) links[m].click();
      break;
    }
  }

  return 'ok: filters set (近十天 + <省份> + 交易公告)';
})()"
```

**等待 2 秒**，让页面处理筛选条件的 AJAX 请求：

```
browser act kind:wait duration:2000
```

#### Step 3b：输入关键词 + 点击搜索

```javascript
browser evaluate expression:"(function() {
  var input = document.querySelector('input[placeholder*=\"关键字\"]');
  if (!input) input = document.querySelector('.search_key input');
  if (input) {
    var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeInputValueSetter.call(input, '<关键词>');
    input.dispatchEvent(new Event('input', {bubbles: true}));
    input.dispatchEvent(new Event('change', {bubbles: true}));
  }

  var btns = document.querySelectorAll('button, input[type=button], a');
  for (var n = 0; n < btns.length; n++) {
    if (btns[n].textContent.trim() === '搜索') {
      btns[n].click();
      return 'ok: keyword set, search triggered';
    }
  }
  var searchBtn = document.querySelector('.search_btn') || document.querySelector('[onclick*=search]');
  if (searchBtn) { searchBtn.click(); return 'ok: fallback search clicked'; }
  return 'error: search button not found';
})()"
```

**如果返回 `error`**：用 `browser snapshot` 获取最新页面结构，找到搜索按钮的 ref，用 `browser click ref:"<ref>"` 点击。

**等待 3 秒**，让搜索结果加载：

```
browser act kind:wait duration:3000
```

### Step 4：验证筛选条件（仅第 1 个关键词执行）

`browser screenshot` 截图，然后验证：

```javascript
browser evaluate expression:"(function() {
  var r = {};
  var links = document.querySelectorAll('.search_tiaojian a');
  for (var i = 0; i < links.length; i++) {
    var cl = (links[i].className || '') + ' ' + (links[i].parentElement ? links[i].parentElement.className : '');
    if (cl.indexOf('active') >= 0 || cl.indexOf('selected') >= 0 || cl.indexOf('on') >= 0)
      r.timeRange = links[i].textContent.trim();
  }
  var selects = document.querySelectorAll('select');
  for (var j = 0; j < selects.length; j++) {
    if (selects[j].selectedIndex > 0) { r.province = selects[j].options[selects[j].selectedIndex].text; break; }
  }
  if (!r.province) r.province = '不限';
  for (var k = 0; k < links.length; k++) {
    var t = links[k].textContent.trim();
    var kcl = (links[k].className || '') + ' ' + (links[k].parentElement ? links[k].parentElement.className : '');
    if ((t === '交易公告' || t === '成交公示') && (kcl.indexOf('active') >= 0 || kcl.indexOf('selected') >= 0))
      r.infoType = t;
  }
  var input = document.querySelector('input[placeholder*=\"关键字\"]');
  r.keyword = input ? input.value : '';
  return JSON.stringify(r);
})()"
```

验证：`timeRange`=近十天, `province`=目标省份, `infoType`=交易公告, `keyword`=当前关键词。

**验证流程（硬性门槛，不可跳过）**：
1. 如果全部一致 → 验证通过，继续
2. 如果任何条件不一致 → **立即**重新执行 Step 3a + 等 2 秒 + Step 3b + 等 3 秒 + 再次执行 Step 4 验证
3. 最多重试 **2 次**（共 3 次验证机会）
4. 如果 3 次验证都失败 → **停止执行，告知用户"筛选条件设置失败，请检查浏览器状态"**。绝对不能带着错误的筛选条件继续，否则所有结果都是错的

**验证通过后，筛选条件在整个搜索会话中保持不变。后续关键词不再重新设置筛选条件，只换关键词。**

---

### 🔁 Step 5~7：对每个关键词循环执行

### Step 5：切换关键词（第 2 个及以后的关键词执行）

**不刷新页面、不重新设置筛选条件。必须分两步执行，中间加等待。**

#### Step 5a：清空并输入新关键词

```javascript
browser evaluate expression:"(function() {
  var input = document.querySelector('input[placeholder*=\"关键字\"]');
  if (!input) input = document.querySelector('.search_key input');
  if (input) {
    var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeInputValueSetter.call(input, '');
    input.dispatchEvent(new Event('input', {bubbles: true}));
    nativeInputValueSetter.call(input, '<当前关键词>');
    input.dispatchEvent(new Event('input', {bubbles: true}));
    input.dispatchEvent(new Event('change', {bubbles: true}));
  }
  return 'ok: keyword set to <当前关键词>';
})()"
```

**等待 1 秒**，让输入框的值同步到页面 JS 状态：

```
browser act kind:wait duration:1000
```

#### Step 5b：点击搜索

```javascript
browser evaluate expression:"(function() {
  var btns = document.querySelectorAll('button, input[type=button], a');
  for (var n = 0; n < btns.length; n++) {
    if (btns[n].textContent.trim() === '搜索') {
      btns[n].click();
      return 'ok: search triggered';
    }
  }
  var searchBtn = document.querySelector('.search_btn') || document.querySelector('[onclick*=search]');
  if (searchBtn) { searchBtn.click(); return 'ok: fallback search clicked'; }
  return 'error: search button not found';
})()"
```

**如果返回 `error`**：用 `browser snapshot` 获取最新页面结构，找到搜索按钮的 ref，用 `browser click ref:"<ref>"` 点击。

**等待 3 秒**，让搜索结果加载：

```
browser act kind:wait duration:3000
```

### Step 6：抓取数据（含结果校验）

`browser screenshot` 截图。`browser snapshot refs:"aria"` 提取搜索记录总数、每条公告详情、分页信息。

**结果校验（每个关键词都必须执行）**：用 evaluate 检查当前搜索框中的关键词是否正确：

```javascript
browser evaluate expression:"(function() {
  var input = document.querySelector('input[placeholder*=\"关键字\"]');
  return input ? input.value : '';
})()"
```

- 如果返回值**不是当前关键词** → 说明上一步换词或搜索失败了。**立即**回到 Step 5a 重新换词 + 搜索，最多重试 1 次。仍失败则记入 emptyKeywords 并标注"搜索失败"，继续下一个关键词。
- 如果返回值**是当前关键词** → 校验通过，继续：
  - 记录数为 0 → 加入 `emptyKeywords`，**跳过 Step 7，直接进入下一个关键词**
  - 记录数 > 0 → 存入 `results[<当前关键词>]`，继续 Step 7

### Step 7：翻页抓取

```javascript
browser evaluate expression:"(function() {
  var pageLinks = document.querySelectorAll('.pagination a, .page a, [class*=page] a');
  for (var i = 0; i < pageLinks.length; i++) {
    if (pageLinks[i].textContent.trim() === '<目标页码>') {
      pageLinks[i].click();
      return 'ok: clicked page <目标页码>';
    }
  }
  for (var j = 0; j < pageLinks.length; j++) {
    if (pageLinks[j].textContent.indexOf('下一页') >= 0 || pageLinks[j].title === '下一页') {
      pageLinks[j].click();
      return 'ok: clicked next page';
    }
  }
  return 'error: page link not found';
})()"
```

等待 3 秒 → screenshot → snapshot 抓取数据。重复直到达到用户指定页数或无更多页。

### 🔁 循环控制

完成当前关键词后：
1. 输出进度日志：`[N/总数] 关键词: XX条 ✓`
2. 如果还有下一个关键词 → 回到 **Step 5** 换关键词继续
3. **安全刷新机制**：每搜完 **5 个关键词**，如果还有更多，执行一次完整页面刷新并重新设置筛选条件（即重新执行 Step 2 → Step 3a/3b → Step 4 验证，用下一个关键词）。Step 4 验证同样是硬性门槛，不通过不能继续

---

### Step 8：空结果批量处理

所有关键词跑完后，如果 `emptyKeywords` 为空则直接到 Step 9。

如果有无结果的关键词，一次性向用户汇报：
- 多词组合：识别主体词（核心名词），建议重搜。如"新冠医疗"→主体词"新冠"
- 单个词：标记"无法拆分"

> 以下关键词无结果：
> 1. 「新冠医疗」— 建议用「新冠」重搜
> 2. 「足球」— 单个词，无法拆分
>
> 哪些需要重搜？哪些跳过？

等待用户回复后，对需要重搜的关键词从 Step 5 开始执行。

### Step 9：生成 HTML 报告（不可跳过）

文件名：`ggzy_report_<YYYYMMDD>_<HHmmss>.html`

用 `exec` 或 `write_file` 写入以下模板（用实际数据替换 `{{占位符}}`，`{{#循环}}...{{/循环}}` 对每项重复）：

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>公共资源交易公告搜索报告</title>
<style>
  body { font-family: -apple-system, "Microsoft YaHei", sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; color: #333; }
  h1 { color: #1a56db; border-bottom: 2px solid #1a56db; padding-bottom: 10px; }
  h2 { color: #1e40af; margin-top: 40px; border-left: 4px solid #1e40af; padding-left: 12px; }
  .summary { background: #f0f7ff; border-radius: 8px; padding: 16px 20px; margin: 16px 0; }
  .summary p { margin: 4px 0; }
  .keyword-tag { display: inline-block; background: #dbeafe; color: #1e40af; padding: 2px 10px; border-radius: 12px; margin: 2px 4px; font-size: 14px; }
  .empty-tag { background: #fee2e2; color: #991b1b; }
  table { width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 14px; }
  th { background: #1e40af; color: #fff; padding: 10px 8px; text-align: left; }
  td { padding: 8px; border-bottom: 1px solid #e5e7eb; }
  tr:hover td { background: #f9fafb; }
  a { color: #1a56db; text-decoration: none; }
  a:hover { text-decoration: underline; }
  .screenshot { max-width: 100%; border: 1px solid #e5e7eb; border-radius: 4px; margin: 8px 0; }
  .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 12px; }
  .no-result { background: #fef2f2; border-radius: 8px; padding: 12px 16px; color: #991b1b; }
</style>
</head>
<body>
<h1>公共资源交易公告搜索报告</h1>
<div class="summary">
  <p><strong>生成时间：</strong>{{生成时间}}</p>
  <p><strong>搜索条件：</strong>省份={{省份}}，发布时间=近十天，信息类型=交易公告</p>
  <p><strong>关键词：</strong>{{#每个关键词}}<span class="keyword-tag">{{关键词}} ({{记录数}}条)</span>{{/每个关键词}}</p>
  <p><strong>总记录数：</strong>{{总记录数}} 条</p>
</div>
{{#每个有结果的关键词}}
<h2>「{{关键词}}」— {{记录数}} 条结果</h2>
<table>
  <thead><tr><th>序号</th><th>标题</th><th>日期</th><th>省份</th><th>业务类型</th><th>信息类型</th></tr></thead>
  <tbody>
    {{#每条公告}}<tr><td>{{序号}}</td><td><a href="{{链接}}" target="_blank">{{标题}}</a></td><td>{{日期}}</td><td>{{省份}}</td><td>{{业务类型}}</td><td>{{信息类型}}</td></tr>{{/每条公告}}
  </tbody>
</table>
{{#如果有截图}}{{#每张截图}}<img class="screenshot" src="{{截图路径}}" alt="第{{页码}}页截图">{{/每张截图}}{{/如果有截图}}
{{/每个有结果的关键词}}
{{#如果有无结果的关键词}}
<h2>无结果的关键词</h2>
<div class="no-result"><ul>{{#每个无结果关键词}}<li><span class="keyword-tag empty-tag">{{关键词}}</span></li>{{/每个无结果关键词}}</ul></div>
{{/如果有无结果的关键词}}
<div class="footer">
  <p>数据来源：<a href="https://www.ggzy.gov.cn" target="_blank">全国公共资源交易平台</a> | 由 OpenClaw ggzy-search Skill 自动生成</p>
</div>
</body>
</html>
```

写入后向用户报告文件路径和每页截图路径。

## 故障排除

| 现象 | 处理 |
|------|------|
| 第 1 个关键词结果数远多于预期 | 筛选条件没生效。Step 3a 和 3b 之间必须等 2 秒。Step 4 验证不过必须立即重试，禁止跳过 |
| 后续关键词结果不对（显示上一个词的结果） | Step 6 的结果校验会检测到。Step 5a/5b 之间必须等 1 秒，校验失败则自动重试 Step 5 |
| evaluate 返回 error: search button not found | 用 snapshot 找搜索按钮 ref，改用 click ref 点击 |
| 第 6+ 个关键词出现异常 | 安全刷新机制：每 5 个关键词自动执行完整页面刷新 + 重设筛选 |
| 搜索记录数 0 | 记入 emptyKeywords，全部跑完后 Step 8 批量处理 |
| 翻页无反应 | snapshot 获取最新 ref 后 click |

## 示例

用户："搜索以下关键词的广东招标公告：医疗、新冠疫苗、足球"

```
Step 1: 解析 → ["医疗", "新冠疫苗", "足球"]
Step 2: navigate 打开网站
Step 3a: 设置筛选：近十天 + 广东 + 交易公告
  等待 2 秒（让筛选 AJAX 完成）
Step 3b: 输入"医疗" + 点击搜索
  等待 3 秒（让搜索结果加载）
Step 4: 验证筛选条件 ✓
Step 6~7: 抓取 + 翻页
  [1/3] 医疗: 45条 ✓
Step 5a: 清空输入框 → 填入"新冠疫苗"
  等待 1 秒
Step 5b: 点击搜索
  等待 3 秒
Step 6: 抓取 → 0条
  [2/3] 新冠疫苗: 0条（无结果）✓
Step 5a: 清空输入框 → 填入"足球"
  等待 1 秒
Step 5b: 点击搜索
  等待 3 秒
Step 6~7: 抓取 + 翻页
  [3/3] 足球: 8条 ✓
Step 8: 汇报「新冠疫苗」无结果，建议用「新冠」重搜 → 用户确认
Step 9: 生成 ggzy_report_20260316_210000.html
```
